CCU Banking Access Terminal
Crimson Credit Union - member services node CCU-CORE-2

  ccu_term               the service binary, as deployed
  libc.so.6              the libc it runs against (Ubuntu GLIBC 2.35)
  ld-linux-x86-64.so.2   the matching loader

To run it locally against the shipped libc:

  patchelf --set-interpreter ./ld-linux-x86-64.so.2 \
           --set-rpath . ccu_term

Test credentials are in the challenge description.
